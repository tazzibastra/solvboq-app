@echo off
rem Removes SolvBoQ for the current Windows user.
setlocal
if not exist "%~dp0revit-year.txt" (
  echo This is the template, not the uninstaller. Run install\SolvBoQ-Revit2025\uninstall.cmd instead.
  pause
  exit /b 1
)
set /p YEAR=<"%~dp0revit-year.txt"
set "DEST=%APPDATA%\Autodesk\Revit\Addins\%YEAR%"
if exist "%DEST%\SolvBoQ.addin" del "%DEST%\SolvBoQ.addin"
if exist "%DEST%\SolvBoQ" rmdir /s /q "%DEST%\SolvBoQ"
echo SolvBoQ is removed from Revit %YEAR%.
pause
