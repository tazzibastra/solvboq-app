@echo off
rem Installs SolvBoQ for the current Windows user. No admin rights or .NET SDK needed.
setlocal
if not exist "%~dp0revit-year.txt" (
  echo This is the template, not the installer. Run install\SolvBoQ-Revit2025\install.cmd instead.
  pause
  exit /b 1
)
set /p YEAR=<"%~dp0revit-year.txt"
set "DEST=%APPDATA%\Autodesk\Revit\Addins\%YEAR%"
tasklist /fi "imagename eq Revit.exe" | find /i "Revit.exe" >nul && (
  echo Revit is running. Close Revit, then run install.cmd again.
  pause
  exit /b 1
)
if not exist "%DEST%\SolvBoQ" mkdir "%DEST%\SolvBoQ"
copy /y "%~dp0SolvBoQ.addin" "%DEST%\" >nul
copy /y "%~dp0SolvBoQ\SolvBoQ.Readiness.dll" "%DEST%\SolvBoQ\" >nul
rem Downloaded from the SolvBoQ page: clear Windows' "came from the internet" mark, so Revit loads the add-in without complaint
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Item -LiteralPath '%DEST%\SolvBoQ.addin','%DEST%\SolvBoQ\SolvBoQ.Readiness.dll' | Unblock-File" >nul 2>&1
if exist "%DEST%\LevelProbe.addin" del "%DEST%\LevelProbe.addin"
if exist "%DEST%\LevelProbe" rmdir /s /q "%DEST%\LevelProbe"
echo SolvBoQ is installed for Revit %YEAR%.
echo Open Revit, allow the add-in when asked, then use the SolvBoQ tab.
pause
