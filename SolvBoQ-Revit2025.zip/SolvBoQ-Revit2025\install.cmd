@echo off
rem Installs SolvBoQ for the current Windows user. No admin rights or .NET SDK needed.
setlocal
if not exist "%~dp0revit-year.txt" (
  echo This is the template, not the installer. Run install\SolvBoQ-Revit2025\install.cmd instead.
  pause
  exit /b 1
)
set /p YEAR=<"%~dp0revit-year.txt"
set "DEST=%APPDATA%\Autodesk\Revit\Addins\%YEAR%"
if not exist "%DEST%\SolvBoQ" mkdir "%DEST%\SolvBoQ"
rem Copy first, and stop only if Windows refuses because the add-in is in use. A Revit.exe left in the background after Revit
rem was closed (or another user's Revit) doesn't hold this file, so it no longer blocks the install (9 Nov 2026).
copy /y "%~dp0SolvBoQ\SolvBoQ.Readiness.dll" "%DEST%\SolvBoQ\" >nul 2>&1
if errorlevel 1 goto inuse
copy /y "%~dp0SolvBoQ.addin" "%DEST%\" >nul 2>&1
if errorlevel 1 goto inuse
rem Downloaded from the SolvBoQ page: clear Windows' "came from the internet" mark, so Revit loads the add-in without complaint
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Item -LiteralPath '%DEST%\SolvBoQ.addin','%DEST%\SolvBoQ\SolvBoQ.Readiness.dll' | Unblock-File" >nul 2>&1
if exist "%DEST%\LevelProbe.addin" del "%DEST%\LevelProbe.addin"
if exist "%DEST%\LevelProbe" rmdir /s /q "%DEST%\LevelProbe"
echo SolvBoQ is installed for Revit %YEAR%.
echo Open Revit, allow the add-in when asked, then use the SolvBoQ tab.
pause
exit /b 0

:inuse
echo.
echo The SolvBoQ add-in couldn't be replaced: Revit still has it open.
tasklist /fi "imagename eq Revit.exe" | "%SystemRoot%\System32\find.exe" /i "Revit.exe" >nul && (
  echo Revit.exe is still running, even if no window shows. Close Revit, or end "Revit" in Task Manager
  echo ^(Ctrl+Shift+Esc, Details tab, Revit.exe, End task^), then run install.cmd again.
) || (
  echo Close any program that may be using it, then run install.cmd again.
)
pause
exit /b 1
